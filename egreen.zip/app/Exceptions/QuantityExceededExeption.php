<?php

namespace App\Exceptions;

use Exception;

class QuantityExceededExeption extends Exception
{
    //
}
